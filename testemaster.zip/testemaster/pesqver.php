<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VISUALIZAR USU</title>
    <link rel="stylesheet" href="pesqver.css">
</head>
<body>
<div class="card-container">
        <button id='button'><h1>SISTEMA</h1></button>
        <div class="card">

            <img src="logo-telecall.png" alt="Imagem do card">
            <h2>🔎​ Digite o usuário que deseja visualizar:</h2>
            <form action="">

                <input type="text" name="nameidusuario" id="ididusuario" placeholder='ID do USUÁRIO'>
                
                <a href="telaescolha.php"><button type='button' class='botao' >Voltar 🠔</button></a>
                <input type="submit" value="Visualizar">

            </form>
        </div>
    </div>
</body>
</html>