<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SISTEMA-MASTER</title>
    
    <link rel="stylesheet" href="telaescolha.css">
</head>
<body>
    <div class="card-container">
        <button id='button'><h1>SISTEMA</h1></button>
        <div class="card">
            <img src="logo-telecall.png" alt="Imagem do card">
            <h2>🔎​ Escolha o que deseja fazer:</h2>
            <a href="pesqver.php"><button class='botao'>Ver usuário</button></a>
            <a href="pesqedit.php"><button class='botao'>Editar usuário</button></a>
        
        </div>
    </div>
</body>
</html>