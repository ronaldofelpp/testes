
<?php
    $idusuario = $_GET['nameidusuario'];

    echo $idusuario
    #SELECT  FROM  WHERE '$idusuario'
?>